# AdminResetstationsPost200Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] 

## Example

```python
from openapi_client.models.admin_resetstations_post200_response import AdminResetstationsPost200Response

# TODO update the JSON string below
json = "{}"
# create an instance of AdminResetstationsPost200Response from a JSON string
admin_resetstations_post200_response_instance = AdminResetstationsPost200Response.from_json(json)
# print the JSON string representation of the object
print(AdminResetstationsPost200Response.to_json())

# convert the object into a dict
admin_resetstations_post200_response_dict = admin_resetstations_post200_response_instance.to_dict()
# create an instance of AdminResetstationsPost200Response from a dict
admin_resetstations_post200_response_from_dict = AdminResetstationsPost200Response.from_dict(admin_resetstations_post200_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


